"""Create original synthetic Beebo test clips; no external media, fonts or network.
Set BEEBO_FFMPEG to an existing FFmpeg executable (not included in this pack).
At most two encoder/filter threads, sequential clips.
"""
from pathlib import Path
import os, subprocess
ROOT=Path(__file__).resolve().parents[1]
FFMPEG=os.environ.get('BEEBO_FFMPEG','ffmpeg')
W,H=480,270
# Hand-written geometric pixel glyphs; no font file or third-party artwork.
FONT={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'I':['11111','00100','00100','00100','00100','00100','11111'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','10101','10011','10001','10001','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'0':['01110','10001','10011','10101','11001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
'.':['00000','00000','00000','00000','00000','00100','00100'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
' ':['00000']*7}
def rect(buf,x,y,w,h,color):
    x=max(0,x);y=max(0,y);w=min(w,W-x);h=min(h,H-y)
    if w<=0 or h<=0:return
    row=bytes(color)*w
    for yy in range(y,y+h):buf[(yy*W+x)*3:(yy*W+x+w)*3]=row
def text(buf,words,x,y,scale=2,color=(240,244,250)):
    for letter in words:
        for yy,line in enumerate(FONT[letter]):
            for xx,value in enumerate(line):
                if value=='1':rect(buf,x+xx*scale,y+yy*scale,scale,scale,color)
        x+=6*scale
def frame(n,fps,duration):
    buf=bytearray(bytes((14,21,31))*(W*H))
    text(buf,'BEEBO ORIGINAL TEST',24,18,3)
    colors=[(218,84,73),(223,166,69),(127,179,94),(59,166,161),(76,125,202),(146,99,182)]
    for i,color in enumerate(colors):
        rect(buf,24+i*72,60,64,85,color)
    # Slow motion marker; no flash frames or borrowed test-pattern asset.
    x=24+int((n%(fps*4))/(fps*4-1)*408)
    rect(buf,x,151,24,12,(240,244,250))
    text(buf,'FRAME '+str(n).zfill(4),24,180,2)
    text(buf,'SEC '+format(n/fps,'05.1f'),268,180,2)
    text(buf,'RESUME TEST 65 SEC' if duration>5 else 'TEST CLIP 5 SEC',24,215,2)
    rect(buf,24,249,int(432*n/max(1,duration*fps-1)),5,(86,189,182))
    return buf
def render(relative,duration,fps,legacy=False):
    out=ROOT/relative;out.parent.mkdir(parents=True,exist_ok=True)
    args=[FFMPEG,'-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','2','-filter_complex_threads','2',
      '-f','rawvideo','-pix_fmt','rgb24','-s',str(W)+'x'+str(H),'-r',str(fps),'-i','pipe:0',
      '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration='+str(duration),
      '-map','0:v:0','-map','1:a:0','-af','volume=0.08,afade=t=in:d=0.10,afade=t=out:st='+str(duration-.10)+':d=0.10',
      '-t',str(duration),'-pix_fmt','yuv420p','-threads','2']
    if legacy:args+=['-c:v','msmpeg4','-q:v','5','-c:a','pcm_s16le']
    else:args+=['-c:v','libopenh264','-b:v','250k','-maxrate','350k','-bufsize','700k','-g',str(fps*2),'-profile:v','constrained_baseline','-level','3.0','-c:a','aac','-b:a','48k','-movflags','+faststart']
    args+=['-metadata','title=Beebo original synthetic test clip','-metadata','comment=Original moving graphics and generated quiet tone; no third-party media or fonts',str(out)]
    proc=subprocess.Popen(args,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        for n in range(duration*fps):proc.stdin.write(frame(n,fps,duration))
        proc.stdin.close()
        stderr=proc.stderr.read().decode(errors='replace');code=proc.wait()
    except BrokenPipeError:
        stderr=proc.stderr.read().decode(errors='replace');proc.wait();raise RuntimeError(stderr)
    if code:raise RuntimeError(stderr)
    print(relative+': '+str(out.stat().st_size)+' bytes',flush=True)
if __name__=='__main__':
    render('conversion/Beebo_Original_Conversion_Test_5s.avi',5,24,True)
    render('reference/Beebo_Original_Playback_Test_5s.mp4',5,24)
    render('resume/Beebo_Original_Resume_Test_65s.mp4',65,15)

