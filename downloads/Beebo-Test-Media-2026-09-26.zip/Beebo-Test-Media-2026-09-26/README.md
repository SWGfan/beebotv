# Beebo original sample tests

Small, original synthetic media for optional human testing. No film, music recording, photograph, third-party font, account information or downloaded media is included. The graphics, pixel lettering, captions and quiet 440 Hz tone were generated for this pack.

## Files

| File | What it contains | Intended check |
| --- | --- | --- |
| `conversion/Beebo_Original_Conversion_Test_5s.avi` | 5 seconds, 480×270, 24 fps, Microsoft MPEG-4 v3 video + PCM audio | A real legacy-codec conversion candidate; Beebo's inspected conversion rules select video re-encoding. |
| `reference/Beebo_Original_Playback_Test_5s.mp4` | Matching original 5-second graphics, H.264 constrained-baseline + AAC | Basic playback/reference comparison; inspected rules select no conversion. |
| `resume/Beebo_Original_Resume_Test_65s.mp4` | 65 seconds, 480×270, 15 fps, H.264 + AAC | Pause/resume, seeking and downloaded playback. |
| Matching `.srt` files beside both 5-second clips | Two original caption cues | Caption selection, timing and readability, when supported by the player. |
| `tv-demo/Beebo Synthetic Test Show/Season 1/...S01E01.mp4` | Copy of the 65-second resume sample | TV grouping, Continue button and episode position marker. |
| `tv-demo/...S01E03.mp4` and `Season 3/...S03E01.mp4` | Copies of the 5-second reference | TV season ordering and jumping. |

The same reference content is intentionally reused in the three TV example files. They are not different story episodes.

## Use only a separate test folder

Extract the ZIP. Choose a new test-only folder for the clips you want to add to Beebo. Add the conversion/reference/resume clips through your usual movie-library setup, and the `tv-demo` folder through your usual TV-library setup. Keep each SRT beside its matching video with the same base filename. Do not replace or rename any real library files. Nothing in this pack configures Beebo, changes preferences or submits reports.

## Suggested human checks

1. **Five-second conversion:** add the AVI as a test movie. Inspect Beebo's conversion/status area and try it on the chosen phone or browser. Check that the resulting playable version has moving bars, the counter, captions where selected, and a quiet tone. The AVI is deliberately different from a renamed MP4. Conversion may already run during a scan. A five-second clip can finish too quickly for a progress notification to stay visible; this sample cannot prove a notification appeared or persisted.
2. **Reference playback:** open the 5-second MP4. Check picture, motion and quiet audio. The marker moves across the bar area; the displayed frame/time counters increase. Compare it with the converted AVI. Decode/rules checks do not guarantee that a particular browser, phone or Cast device plays correctly.
3. **Captions:** select the matching sidecar captions if the player offers them. Cue one runs from 0.5–2.3 seconds; cue two from 2.7–4.8 seconds. Check that they are readable and not clipped. The counters drawn into the video are separate from subtitles.
4. **Resume:** use the 65-second clip. Play beyond 35 seconds, pause around 40 seconds, then return to the library. Allow the normal progress report to finish, reopen Continue, and check the actual resumed position. For the TV Continue button/row marker, use the `S01E01` copy in the TV folder. Beebo's inspected server rule requires more than 30 seconds and less than 95% completion; a five-second clip is unsuitable for this check. Do not let the 65-second sample finish before checking resume.
5. **Download/offline (optional):** download the reference or resume clip using the app's existing controls, then test your normal offline workflow. Check Downloads scrolling and descriptions at your usual font size, and optionally at a larger system text size. Restore any test preference you changed.
6. **TV organization:** confirm Season 1 contains E01 and E03, and Season 3 contains E01. Use the season jump controls. Only those three local files exist.

## Important limit: the invented TV show is not a missing-metadata test

`S01E02` and all of Season 2 are deliberately absent from this folder, but **that does not establish that those episodes or seasons actually exist**. This is an invented show with no verified external episode catalogue. A safe missing-episode view should not invent gaps from these filenames. No confirmed missing-season result should be expected from this demo alone.

To test metadata-confirmed missing seasons/episodes, use a real show and media you are authorized to use, with a verified metadata match and already-aired episode information, or the project's isolated mocked metadata tests. Do not match this invented show to an unrelated real programme merely to force missing rows.

## What was verified

All six video files passed FFprobe duration/codec checks and complete video/audio decoding with error-fail enabled. Durations are exactly 5.000 or 65.000 seconds. The current Beebo pure playback-rule check classifies the AVI as `video` conversion and every MP4 as `none`. A representative reference frame was visually inspected. `VERIFICATION.json` records file-level evidence; `SHA256SUMS.txt` covers every supplied file except itself.

These checks do not establish app conversion, notification delivery, captions on a device, profile isolation, Cast behavior, resume behavior, or offline behavior. Record those as human observations in the existing tester workflow. No automatic quality claims, app installation, account access, real-library change or report submission occurred while creating this pack.

## Permission and regeneration

See `PERMISSION.txt`. No third-party media or font assets were used. FFmpeg executables are not included. `source/generate.py` contains the original procedural graphics and tone setup; it uses an existing FFmpeg with `msmpeg4`, `libopenh264`, AAC and PCM encoding support. Set `BEEBO_FFMPEG` to that executable before running it. Encoding is sequential with at most two encoder/filter threads. The source regenerates the three base clips; the TV examples are byte-for-byte copies described above.
